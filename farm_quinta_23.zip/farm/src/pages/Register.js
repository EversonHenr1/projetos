import Section from "../components/Section"

function Register(){
    return(
       <Section>
        
       </Section>
    )
}

export default Register