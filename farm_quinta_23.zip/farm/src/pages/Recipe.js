import Infos from "../components/Infos";
import Lines from "../components/Lines";
import Section from "../components/Section";
import styles from "./css/Recipe.module.css";
import { FaFire, FaFireAlt} from "react-icons/fa";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";



function Recipe(){
    const [id,setID] = useState(useParams("idRecipe"));
    const [titulo,setTitulo] = useState(null);
    const [imgUrl,setImgUrl] = useState(null);
    const [time,setTime] = useState(null);
    const [porcao,setPorcao] = useState(null);
    const [dificuldade,setDificuldade] = useState(null);
    const [desc,setDesc] = useState(null);
    const [listProcedimento,setListProcedimento] = useState(null);
    const [listIngredientes,setListIngredientes] = useState(null);


    useEffect(()=>{
        axios.get(`/recipe/${id.idRecipe}`).then(
        (response)=>{
            const result = response.data.response[0]
            setTitulo(result.titulo);
            setImgUrl(result.img_url);
            setTime(result.tempo);
            setPorcao(result.porcoes);
            setDificuldade(result.dificuldade);
            setDesc(result.descricao);
            setListProcedimento(result.procedimentos)
            setListIngredientes(result.ingredientes)
        }
        ).catch(err=>console.log(err))

    },[])
 /*    switch(dificuldade){
        case "facil":
            dificuldade = 0;
            break;
        case "medio":
            dificuldade = 1;
            break;
        case "dificil":
            dificuldade = 2;
    } */
    

    return(
        <Section color="F9F9F9" >
            <div className={styles.waveBackground}/>
            <div className={styles.waveBackground}/>
            <div className={styles.borderShadow}/>
            <div className={styles.containerMain}>
                <div className={styles.containerImage}>
                    <img src={imgUrl}></img>
                </div>
                <Lines><h1>{titulo}</h1></Lines>
                <div className={styles.containerInfo}>
                   
                    <Infos>{time}</Infos>
                    <Infos>{dificuldade} </Infos>
                    <Infos>{porcao}</Infos>
                </div>
            </div>
            <div className={styles.containerDesc}>
                <div className={styles.desc}>
                    <p>{desc}</p>
                </div>
                <div className={styles.ingrediente}>
                    <h2>Ingredientes</h2>
                  <ul>
                      {listIngredientes != null && listIngredientes.map((item,index)=> (
                          <li>{item.quantidade} {item.medida} - {item.nome}</li>
                      ))}
                     
                  </ul>
                </div>
            </div>

            <div className={styles.containerProcedimentos}>
                <Lines><h1>Procedimentos</h1></Lines>
                <div className={styles.procedimento}>
                    
                { listProcedimento != null && listProcedimento.map((item,index)=> (
                <div>
                    <h3>{index + 1} - Procedimento</h3>
                    <div>{item.body}</div>
                </div>))}

                </div>
            </div>
        
            

        </Section>
    )
}

export default Recipe;