import Infos from "../components/Infos";
import Lines from "../components/Lines";
import Section from "../components/Section";
import styles from "./css/Recipe.module.css";
import {} from "react-icons"
import { FaFire, FaFireAlt, FaFireExtinguisher } from "react-icons/fa";


function Recipe(){

    return(
        <Section color="F9F9F9" >
            <div className={styles.waveBackground}/>
            <div className={styles.waveBackground}/>
            <div className={styles.borderShadow}/>
            <div className={styles.containerMain}>
                <div className={styles.containerImage}>
                    <img src="https://s2-casavogue.glbimg.com/GRF9KCq-1hiz5uSs-xX9Go_KqIc=/0x0:2048x1365/984x0/smart/filters:strip_icc()/i.s3.glbimg.com/v1/AUTH_d72fd4bf0af74c0c89d27a5a226dbbf8/internal_photos/bs/2022/p/X/eb4KQdToys327cGqnRGg/receita-ceboloni-bacon.jpg"></img>
                </div>
                <Lines><h1>Hamburguer</h1></Lines>
                <div className={styles.containerInfo}>
                   
                    <Infos>30 minutos</Infos>
                    <Infos>  <FaFire/>  <FaFire/> <FaFireAlt/> </Infos>
                    <Infos>serve 10 pessoas</Infos>
                </div>
            </div>
            <div className={styles.containerDesc}>
                <div className={styles.desc}>
                    <p>os segredos do melhor pão dos lanchinho na cada da vovó, simplificada aqui para varios momentos de união familiar</p>
                </div>
                <div className={styles.ingrediente}>
                    <h2>Ingredientes</h2>
                  <ul>
                      <li>480g de farinha de trigo</li>
                      <li>480g de farinha de trigo</li>
                      <li>480g de farinha de trigo</li>
                      <li>480g de farinha de trigo</li>
                      <li>480g de farinha de trigo</li>
                  </ul>
                </div>
            </div>
            <div className={styles.containerProcedimentos}>
                <Lines><h1>Procedimentos</h1></Lines>
                <div className={styles.procedimento}>
                    <div>
                        <h3>1 - Procedimento</h3>
                        <div>Meu procedimento</div>
                    </div>
                    <div>
                        <h3>2 - Procedimento</h3>
                        <div>Meu procedimento</div>
                    </div>
                    <div>
                        <h3>3 - Procedimento</h3>
                        <div>Meu procedimento</div>
                    </div>
                </div>
            </div>
        
            

        </Section>
    )
}

export default Recipe;