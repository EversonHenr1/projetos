import { useState } from "react"
import SelectType from "../components/SelectType"
import DeleteButton from "../components/DeleteButton"
import Selections from "./Selections"
import styles from "./css/Ingredients.module.css"
import { FaTimes } from "react-icons/fa"

function Ingredients({}){
  
    return(
        <div className={styles.container_Ingred}>
            <h3>Ingrediente</h3>
            <Selections/>
            <span>x</span>
        </div>
    )
}

export default Ingredients