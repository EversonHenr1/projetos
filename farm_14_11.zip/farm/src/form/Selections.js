import styles from "./css/Selections.module.css"

function Selections({opcoes,change,name,value}){
   
    return(
        <select name={name} id={name}   value={value} className={styles.selection} onChange={change}>
            <option disabled value="">selecione..</option>
            {
                opcoes ? opcoes.map((element)=>(
                    <option id={element.id} value={element.body} key={element.id}>{element.body}</option>
                )) : 
                (<option>Sem opções</option>)
            }
        </select>
    )
}
export default Selections