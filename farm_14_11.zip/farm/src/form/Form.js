import Button from "../components/Button"
import Ingredients from "./Ingredients"
import Input from "./Input"
import Proceeding from "./Proceeding"
import TextAreaAutoHeight from "./TextAreaAutoHeight"
import ImageUpload from "../components/ImageUpload"
import styles from "./css/Form.module.css"
import { FaCarrot, FaFire, FaRegClock, FaUtensils } from "react-icons/fa"
import Selections from "./Selections"
import { useState } from "react"
import axios from "axios"

function Form(){ 
    

    const [valueTitulo,setValueTitulo] = useState("")
    const [valueDesc,setValueDesc] = useState("")
    const [valueTime,setValueTime] = useState("")
    const [valuePorcoes,setValuePorcoes] = useState("")
    const [valueDificuldade,setValueDificuldade] = useState("")
    const [valueImgUrl,setValueImgUrl] = useState("")

    const optionsTime = [{id:"5min", body:"5 minutos"},{id:"15min", body:"15 minutos"},
    {id:"30min", body:"30 minutos"},{id:"45min", body:"45 minutos"},{id:"1h", body:"1 hora"},
    {id:"1h30min", body:"1h e 30 minutos"},{id:"2h", body:"2 horas"}, {id:"mais3horas", body:"mais que 2 horas"}
    ]
    const optionsPorçoes = [{id:"1porção", body:"1 porção"},{id:"1a3porções", body:"1 a 3 porções"},{id:"3a5porções", body:"3 a 5 porções"},{id:"5a7porções", body:"5 a 7 porções"},{id:"10oumaisporções", body:"10 ou mais porções"} ]

    const optionsDificuldade =[{id:"Facil",body:"Facil"},{id:"Mediana",body:"Mediana"},{id:"Dificil",body:"Dificil"}]

    const handleInput = (e)=>{
        const value = e.target.value;
        const name = e.target.name;
        console.log(name)
        switch(name){
            case "inpTitulo":
                setValueTitulo(value)
                break;
            case "inpDesc":
                setValueDesc(value)
                break;
            case "inpImg":
                setValueImgUrl(value)
                break;
        }
    }
    const handleSelect = (e)=>{
        const value = e.target.value;
        const name = e.target.name;
        switch(name){
            case "selectTime":
                setValueTime(value);
                break;
            case "selectPorcoes":
                setValuePorcoes(value);
                break;
            case "selectDificuldade":
                setValueDificuldade(value);
                break;
        }
        
    }
    
    const handleSubmit = (e)=>{
        e.preventDefault();
        const request = {
            titulo: valueTitulo,
            descricao:valueDesc,
            porcoes:valuePorcoes,
            tempo:valueTime,
            dificuldade:valueDificuldade,
            img:valueImgUrl,
            procedimentos:[],
            ingredientes:[]
        }
        axios.post("/recipe",request).then(data=>console.log(data)).catch(err=>console.log(err))
    }


    return(
        <div className={styles.containerForm}>
            <h2>Adicione Novas Receitas</h2>
            <form onSubmit={handleSubmit}>
               
               
                <Input text="Insira o Titulo"  type="text" name="inpTitulo" required="true" Change={handleInput}  value={valueTitulo}/>
                <TextAreaAutoHeight text="Digite a Descrição" name="inpDesc" required="true" value={valueDesc} change={handleInput} />
                <div className={styles.flexDicas}>
                    <div>
                        <FaRegClock/>
                        <Selections change={handleSelect} value={valueTime} opcoes={optionsTime} name="selectTime" />
                    </div>
                    <div>
                        <FaUtensils/>
                        <Selections change={handleSelect} value={valueDificuldade} name="selectDificuldade" opcoes={optionsDificuldade}/>
                    </div>
                    <div>
                        <FaCarrot/>
                        <Selections change={handleSelect} value={valuePorcoes} name="selectPorcoes"   opcoes={optionsPorçoes}/>
                    </div>
                </div>
                
           {/*          <Ingredients />
                    <Ingredients />
                <Button> +  Ingredientes </Button>
                    <Proceeding/>
                    <Proceeding/>
                <Button> +  Procedimento </Button> */}
                <Input  text="Digite a URL da Imagem" name="inpImg" value={valueImgUrl} Change={handleInput} />
                
                <Button ><FaFire/> Salvar <FaFire/></Button>
                
                
            </form>
        </div>
    )
}

export default Form