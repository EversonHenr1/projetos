import TextAreaAutoHeight from "./TextAreaAutoHeight"
import styles from "./css/Proceeding.module.css"


function Proceeding({}){

    return(
        <div className={styles.containerProcesso}>
            
            <h3>Procedimento</h3>
            
            <TextAreaAutoHeight text="Digite um procedimento" /> 
            <span>x</span>
        </div>
    )
}

export default Proceeding