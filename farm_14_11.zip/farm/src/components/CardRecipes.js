import CardImg from "./CardImg"
import iconHat from "../img/cardRecipes/iconHat.png"
import styles from "./css/CardRecipes.module.css"
import Lines from "../components/Lines"
import { FaCookie } from "react-icons/fa"
import { useState } from "react"


function CardRecipes({receita}){

    const [showDesc,setShowDesc] = useState(false);
    const [desc] = useState(receita.descricao)
    
  
    const formattedDesc = typeof desc === 'string' && desc.length > 120
    ? desc.substring(0, 120) + '...'
    : desc;  


    return(
        <div className={styles.containerRecipes}>
            <img src={iconHat} alt="icone_bigode"/>
            <CardImg image={receita.img_url}/>
            <div className={styles.containerLines}>
                <Lines><h5 className={styles.tittle}>{receita.titulo}</h5></Lines>
                <span>{receita.autor} <FaCookie/> </span> 
                <div className={styles.containerDesc}>
                    <p>{formattedDesc} </p>
                </div>
            </div> 
            
        </div>
    )
}

export default CardRecipes